from data_handling import table_print
from gift import *
from people import *

class WishList(Gift, Person):
    #__init__ Goes ahead and sets up all the attributes as the instructions said
    def __init__(self, bday_kid = "None", wl_num = 0, wl_list = [], address = "None", delivered = "False"):
        self.__bday_kid = bday_kid
        self.__wl_num = wl_num
        self.__wl_list = wl_list
        self.__address = address
        self.__delivered = delivered

    #__str__ will print off what the wishlist looks like so far! If it's called again (if the person selected 'SHOW WISHLIST', this should be updated
        #The wishlist_message is what will be given to the call. It goes ahead and puts whose wishlist it is
        #First, it checks how long the list is for gramatical reasons (gift versus gifts
        #Then, it checks how long each list is. If it's 3, it's safe to assume there is a color, so want to specify what the toy looks like
        #If it's 2, there's no color, so there doesn't need to be a specification. Guess it can say the birthday person just does not care what they get. 
    def __str__(self):
        wishlist_message = "" 
        if self.set_wl_num() > 1:
            wishlist_message += self.set_bday_name() + " has " + str(self.set_wl_num()) + " gifts on their wishlist.\n"
        else:
            wishlist_message += self.set_bday_name() + " has " + str(self.set_wl_num()) + " gift on their wishlist.\n"

        for item in self.set_wl_list():
            if len(item) == 3:
                wishlist_message += "   -{} {} for ${:.2f}\n".format(item[2].title(), item[0].title(), item[1])
            else:
                wishlist_message += "   -{} for ${:.2f}\n".format(item[0].title(), item[1])

        wishlist_message += "\nHave the gifts been delivered?: " + self.set_delivered()
        return wishlist_message

    #All the set_... functions makes sure that I can access this in the first place. I went ahead and protected all the attributes befoee, but still want to make sure
    #   I can access them, so that's where these come to play.
    def set_bday_name(self):
        return self.__bday_kid

    def set_wl_num(self):
        return int(self.__wl_num)

    def set_wl_list(self):
        return self.__wl_list

    def set_address(self):
        return self.__address

    def set_delivered(self):
        return self.__delivered

    """
        All the functions after the setters are ones requiring user input!
        Please go to main to see an explaination.
    """

    #add_gift lets the user add to the original wishlist so long as the input isn't less than or equal to 0. If it' greater than 0, it will ask what the gift is and check to see
    #   if it's already in the list (is_gift_in_wishlist). If it is, it won't add to i, so it'll loop over it again and again until the user finally adds a gift that isn't there.
    #   In order to qualify as a gift, it has to have some price. As shown on add_cost, it says if the gift is, for example, a homemade craft, they should enter 0 as the price.
    #   If they just hit enter, that means it doesn't qualify as a gift.
    #   If there isn't a specific color they want, it should skip it and just add the gift's name and price to the list.
    #   If there is a specific color, it'll still add it, specifying what color it was. 
    def add_gift(self):
        print("\n*~Add a gift~*")
        #FIXME (fixed!): Check if the add_amount is true. If it isn't, it needs to ask again.
        try:
            add_amount = int(input("How many gifts do you want to add?: "))
            if add_amount <= 0:
                print("But you can't add any gifts!")
            else:
                i = 1
                while i <= add_amount:
                    add_gift = input("\nEnter the gift here: ").title()

                    check_gift = self.is_gift_in_wishlist(add_gift)
                    if check_gift == True:
                        print("This gift is already in the wishlist.")
                    else:
                        add_cost = float(input("How much does it cost? (If it's something along the lines of homemade craft, enter 0.00): $"))
                        add_color = input("What's the color of the item? (If there is none, just hit enter): ").title()
                        if add_color:
                            self.set_wl_list().append([add_gift, add_cost, add_color])
                            print("{} {} successfully added! It costs ${:.2f}.\n".format(add_color, add_gift, add_cost))
                        else:
                            self.set_wl_list().append([add_gift, add_cost])
                            print("{} successfully added! It costs ${:.2f}.\n".format(add_gift, add_cost))
                        i += 1
                        
                return self.set_wl_list()
        except ValueError:
            print("This isn't a valid input.")

    #delete_gift will, of course, delete a gift. Maybe they already bought the gift, or it's too expensive that the people buying it can't get it. Nonetheless, it should just get rid of it
    #   At least, so long as the gift is there. Like with add_gift, it will use is_gift_in_wishlist to make sure it's there in the first place. If it is, it will allow the program
    #   to look through every list in the wishlist. If it's equal to delete_gift (the input), it'll delete the entire thing. If it's not there, though, then it should say it doesn't exist.
    #   It will loop over and over again until the user actually entered a gift that exists. After, it should show what the wishlist looks like.
    #   If the user put something less than or equal to 0, though, it shouldn't execute - instead, it ends it, because that must mean the user didn't want to delete any gifts, right?
    def delete_gift(self):
        print("\n*~Delete a gift~*")
        print("These are the wishlist items the birthday child wants: ")
        for item in self.set_wl_list():
            print("   -" + item[0].title())

        delete_amount = int(input("How many gifts do you want to delete?: "))
        i = 1
        if delete_amount <= 0:
            print("Cannot delete any gifts.")
        else:
            while i <= delete_amount:
                delete_gift = input("Which item do you want to delete?: ").title()

                check_gift = self.is_gift_in_wishlist(delete_gift)

                if check_gift == True:
                    for list in self.set_wl_list():
                        for item in list:
                            if item == delete_gift:
                                self.set_wl_list().remove(list)
                                i += 1
                else:
                    print("This item doesn't exist!\n")
                
        print("Gifts successfully deleted! This is what's in the wishlist looks now: ")
        for item in self.set_wl_list():
            print("   -" + item[0].title())
        
        
    
    #purchase_gift just makes delivered equal to true. If this part executes, that means the user shouldn't be able to access the wishlist again.
    #   However, when it changes it, it will take the customer name, what number the wishlist was, and the wishlist itself to table_print to give the person buying it a reciept.
    def purchase_gift(self, customer):
        self.__delivered = "True"
        print("Wishlist item(s) purchased! They will be delivered.\n")
        table_print([customer, self.set_wl_num()], self.set_wl_list())
        return self.__delivered

    #is_it_a_gift is to make sure it's a gift in the first place. If for some reason it doesn't have a cost, that means it's not a gift ('cause money makes the world go 'round...Suppose if
    #   a customer could make the cost equal to 0 if someone is looking for something homemade.
    def is_it_a_gift(self):
        total_true = 0
        is_gift = False
        for list in self.set_wl_list():
            if len(list) > 1:
                total_true += 1

        if total_true == len(self.set_wl_list()):
            is_gift = True
        return is_gift

    #is_gift_in_wishlist loops through to make sure the gift exists. This is mainly for add_gift and delete_gift
    def is_gift_in_wishlist(self, gift):
        gift_exists = False
        for list in self.set_wl_list():
            for item in list:
                if item == gift:
                    gift_exists = True

        return gift_exists

    #gift_dict  goes ahead and keeps track of how many number of gifts there are, in total, to help with narrowing down what the popular gift is
    def gift_dict(wishlist):
        all_gifts = {}
        for list in wishlist:
            for nested_list in list:
                for item in nested_list:
                    if nested_list.index(item) == 0 and item.title() not in all_gifts:
                        all_gifts[item.title()] = 1
                    elif nested_list.index(item) == 0 and item.title() in all_gifts:
                        all_gifts[item.title()] += 1
        return (all_gifts)


if __name__ == "__main__":
    #The first person is to make sure the is_it_a_gift() function worked in the first place. I have an if-else statement to do two different scenarios, depending on the situation,
    #   for each person. If is_it_a_gift() is ever equal to False, it shouldn't work, so it should encourage a new version of the list. The list is fixed for this one on bday_kid2
    bday_kid1 = WishList("Conifer", 1, [['Sweater'], ['GameCube', 140.00]], 'Manhattan, NY', "False")
    print("=-=-=-" + WishList.set_bday_name(bday_kid1).upper() + "'S WISHLIST!-=-=-=")
    if WishList.is_it_a_gift(bday_kid1) == False:
        print("Somewhere in this wishlist, a gift doesn't have enough information to say it really is a gift. Try again.\n")
    else:
        print(WishList.__str__(bday_kid1) + "\n")
        WishList.add_gift(bday_kid1)
        
    print("/|\ " * 30 + "\n")

    #As said, this is the list that works - all the gifts have a name and at least a color, type, whatever is fit (you'll see why on the other bday_kids). Anyway, all of these gifts
    #   are initially put in, dealing with Conifer, Poppy, Ike, and Oxford (we don't count the first Conifer). So long as they are true, it will print out the kid's birthday wishlist,
    #   specifying what the color is if it has it and the cost of it. It's all ordered with dashes (-).
    #If you go all the way to the bottom of my code, you'll see I initially has it to where it was supposed to take user input. I saw later in the instructions to have data already in it,
    #   but I felt if this is someone adding or deleting things from a wishlist, it would be nice to have the user be doing it instead. So for all four kids, they'll go through and
    #   either view it, edit it, or purchase all the items. It's in a while loop because I feel like the user should be able to do something different over and over again until the
    #   user is good with how it looks. After purchasing, it will go to the next kid. At the end of purchasing all of them, it will go see what is the popular gift
    bday_kid2 = WishList("Conifer", 2, [['Sweater', 15.00, 'red'], ['GameCube', 140.00]], 'Manhattan, NY', "False")
    print("=-=-=-" + WishList.set_bday_name(bday_kid2).upper() + "'S WISHLIST!-=-=-=")
    if WishList.is_it_a_gift(bday_kid2) == False:
        print("Somewhere in this wishlist, a gift doesn't have enough information to say it really is a gift. Try again.")
    else:
        print(WishList.__str__(bday_kid2) + "\n")
        while True:
            print("\n-=-=-=REVIEW WISHLIST=-=-=-")
            print("Either edit the wishlist in some way (add or delete a gift), decide whether to purchase the gifts, show what the wishlist looks like, or exit this part and continue\
to the next.")
            option = input("\nSelect what you would like to do:\n\
    ADD (A): Add a gift to the wishlist.\n\
    DELETE (D): Delete a gift from the wishlist.\n\
    PURCHASE (P): Purchase all the gifts in the wishlist.\n\
    SHOW WISHLIST (W): Print what the wishlist looks like.\n")
            if option.upper() == "ADD" or option.upper() == "A":
                WishList.add_gift(bday_kid2)
            elif option.upper() == "DELETE" or option.upper() == "D":
                WishList.delete_gift(bday_kid2)
            elif option.upper() == "PURCHASE" or option.upper() == "P":
                customer = input("Who's buying the gift?: ")
                WishList.purchase_gift(bday_kid2, customer)
                break
            elif option.upper() == "SHOW WISHLIST" or option.upper() == "WISHLIST" or option.upper() == "SHOW" or option.upper() == "W":
                print("=-=-=-" + WishList.set_bday_name(bday_kid2).upper() + "'S WISHLIST!-=-=-=")
                print("\n" + WishList.__str__(bday_kid2))
            else:
                print("Invalid option.")

    print("/|\ " * 30 + "\n")

    bday_kid3 = WishList("Poppy", 3, [['Cactus', 5.00, 'Pink'], ['Acrylic paints', 40.00], ['Sweater', 30.00, 'Gingham'], ['Lights', 20.00, 'Pastel']], 'New York City, NY', "False")
    print("=-=-=-" + WishList.set_bday_name(bday_kid3).upper() + "'S WISHLIST!-=-=-=")
    if WishList.is_it_a_gift(bday_kid3) == False:
        print("Somewhere in this wishlist, a gift doesn't have enough information to say it really is a gift. Try again.")
    else:
        print(WishList.__str__(bday_kid3) + "\n")
        while True:
            print("\n-=-=-=REVIEW WISHLIST=-=-=-")
            print("Either edit the wishlist in some way (add or delete a gift), decide whether to purchase the gifts, show what the wishlist looks like, or exit this part and continue\
to the next.")
            option = input("\nSelect what you would like to do:\n\
    ADD (A): Add a gift to the wishlist.\n\
    DELETE (D): Delete a gift from the wishlist.\n\
    PURCHASE (P): Purchase all the gifts in the wishlist.\n\
    SHOW WISHLIST (W): Print what the wishlist looks like.\n")
            if option.upper() == "ADD" or option.upper() == "A":
                WishList.add_gift(bday_kid3)
            elif option.upper() == "DELETE" or option.upper() == "D":
                WishList.delete_gift(bday_kid3)
            elif option.upper() == "PURCHASE" or option.upper() == "P":
                customer = input("Who's buying the gift?: ")
                WishList.purchase_gift(bday_kid3, customer)
                break
            elif option.upper() == "SHOW WISHLIST" or option.upper() == "WISHLIST" or option.upper() == "SHOW" or option.upper() == "W":
                print("=-=-=-" + WishList.set_bday_name(bday_kid3).upper() + "'S WISHLIST!-=-=-=")
                print("\n" + WishList.__str__(bday_kid3))
            else:
                print("Invalid option.")

    print("/|\ " * 30 + "\n")

    bday_kid4 = WishList("Ike", 4, [['hoodie', 5.00, 'canary'], ['Scarf', 15.00], ['cat', 75.00, 'Snowshoe']], 'Hilo, HI')
    print("=-=-=-" + WishList.set_bday_name(bday_kid4).upper() + "'S WISHLIST!-=-=-=")
    if WishList.is_it_a_gift(bday_kid4) == False:
        print("Somewhere in this wishlist, a gift doesn't have enough information to say it really is a gift. Try again.")
    else:
        print(WishList.__str__(bday_kid4) + "\n")
        while True:
            print("\n-=-=-=REVIEW WISHLIST=-=-=-")
            print("Either edit the wishlist in some way (add or delete a gift), decide whether to purchase the gifts, show what the wishlist looks like, or exit this part and continue\
to the next.")
            option = input("\nSelect what you would like to do:\n\
    ADD (A): Add a gift to the wishlist.\n\
    DELETE (D): Delete a gift from the wishlist.\n\
    PURCHASE (P): Purchase all the gifts in the wishlist.\n\
    SHOW WISHLIST (W): Print what the wishlist looks like.\n")
            if option.upper() == "ADD" or option.upper() == "A":
                WishList.add_gift(bday_kid4)
            elif option.upper() == "DELETE" or option.upper() == "D":
                WishList.delete_gift(bday_kid4)
            elif option.upper() == "PURCHASE" or option.upper() == "P":
                customer = input("Who's buying the gift?: ")
                WishList.purchase_gift(bday_kid4, customer)
                break
            elif option.upper() == "SHOW WISHLIST" or option.upper() == "WISHLIST" or option.upper() == "SHOW" or option.upper() == "W":
                print("=-=-=-" + WishList.set_bday_name(bday_kid4).upper() + "'S WISHLIST!-=-=-=")
                print("\n" + WishList.__str__(bday_kid4))
            else:
                print("Invalid option.")


    print("/|\ " * 30 + "\n")

    bday_kid5 = WishList("Oxford", 5, [['Furby', 150.00], ['Rubber duck', 13.00, 'Resident Evil Tofu']], 'Portland, OR', "False")
    print("=-=-=-" + WishList.set_bday_name(bday_kid5).upper() + "'S WISHLIST!-=-=-=")
    if WishList.is_it_a_gift(bday_kid5) == False:
        print("Somewhere in this wishlist, a gift doesn't have enough information to say it really is a gift. Try again.")
    else:
        print(WishList.__str__(bday_kid5) + "\n")
        while True:
            print("\n-=-=-=REVIEW WISHLIST=-=-=-")
            print("Either edit the wishlist in some way (add or delete a gift) and decide whether to purchase the gifts or show what the wishlist looks like.")
            option = input("\nSelect what you would like to do:\n\
    ADD (A): Add a gift to the wishlist.\n\
    DELETE (D): Delete a gift from the wishlist.\n\
    PURCHASE (P): Purchase all the gifts in the wishlist.\n\
    SHOW WISHLIST (W): Print what the wishlist looks like.\n")
            if option.upper() == "ADD" or option.upper() == "A":
                WishList.add_gift(bday_kid5)
            elif option.upper() == "DELETE" or option.upper() == "D":
                WishList.delete_gift(bday_kid5)
            elif option.upper() == "PURCHASE" or option.upper() == "P":
                customer = input("Who's buying the gift?: ")
                WishList.purchase_gift(bday_kid5, customer)
                break
            elif option.upper() == "SHOW WISHLIST" or option.upper() == "WISHLIST" or option.upper() == "SHOW" or option.upper() == "W":
                print("=-=-=-" + WishList.set_bday_name(bday_kid5).upper() + "'S WISHLIST!-=-=-=")
                print("\n" + WishList.__str__(bday_kid5))
            else:
                print("Invalid option.")


    #This help with seeing what the most popular gift is. This is not the greatest method, but this works. It will look through each list first to see what's the highest in it.
    #   So long as something is larger than 1, it should make that very list the highest/most wanted for now, as well as making the maxmium (amount of people) equal to it.
    #   It will loop through the list again to look at the others and makes sure there isn't something bigger than it. If there is, it will reassign both highest and maximum.
    #   At the end, it adds the list to pop, seeing there are no other values higher than it. 
    #   Multiple gifts can have the same amount of people, so I wanted to go through one more time to see if there were any cases. If there were, it also added it to pop.
    #   At the end, it will loop through every list in pop and print it off, saying what it is and how many people want it
    #   However, if there isn't a max gift, then it should say so.
    print("/|\ " * 30 + "\n")
    track_all_gifts = WishList.gift_dict([WishList.set_wl_list(bday_kid2), WishList.set_wl_list(bday_kid3), WishList.set_wl_list(bday_kid4), WishList.set_wl_list(bday_kid5)])
    print("What's The Most Popular Gift?")
    pop_values = track_all_gifts.items()
    pop_gift_list = list(pop_values)

    #For every gift in the popular gift list
    #   if there is one that is greater than 1
    #       make the maximum equal to that cost
    #       create a list
    #       once done, for every item in the list again
    #           if there's something greater than that
    #           make it the maxmimum
    #       make a list that shows the most popular gifts
    #       go through the list one more time to see if there is a value equal to it
    #           if there are the same amount of people expecting that gift
    #               add it to the list
    #       at the end, print out a format for the gift for every gift in the list
    #   if there isn't anything greater than 1
    #       put something like "there isn't anything higher than 1" to output
    pop = []
    for list in pop_gift_list:
        if list[1] > 1:
            highest = list
            maximum = list[1]
            for other_list in pop_gift_list:
                if other_list[1] > maximum:
                    highest = other_list
                    maximum = other_list[1]
            pop.append(highest)
            for final_list in pop_gift_list:
                if final_list[1] == maximum and final_list != highest:
                    pop.append(final_list)
    if len(pop) > 0:
        for list in pop:
            print("   -{} with {} people wanting it!".format(list[0], list[1]))
    else:
        print("There isn't a gift that's the most popular - the same amount of people want the gifts.")

        
    """
    while True:
        print("=-=-=-BIRTHDAY PERSON'S WISHLIST V1-=-=-=")
        print("Enter what you/the person wants for their birthday so far!\nIf you want the program to end, hit enter or put 'Quit.'")
        bday_num = 1
        bday_name = input("\nEnter the birthday kid's name: ")

        if not bday_name or bday_name.upper() == "QUIT":
            break

        address = input("What is the birthday person's's address? (City, STATE (initials)): ")

        wishlist_amount = input("How many wishlist items do they have?: ")

        try: 
            if int(wishlist_amount) and int(wishlist_amount) > 0:
                i = 1
                wishlist = []
                wishlist_items_list = []

                while i <= int(wishlist_amount):
                    wishlist_item = input("\nEnter wishlist item {}: ".format(str(i))).title()

                    if wishlist_item not in wishlist_items_list:
                        wishlist_items_list.append(wishlist_item)
                        wishlist_item_cost = float(input("Enter wishlist item {}'s cost: $".format(str(i))))
                        wishlist_item_color = input("Enter wishlist item {}'s color: ".format(str(i)))
                        
                        if wishlist_item_color:
                            wishlist.append(([wishlist_item.title(), wishlist_item_cost, wishlist_item_color.title()]))
                        else:
                            wishlist.append(([wishlist_item.title(), wishlist_item_cost]))
                            
                    else:
                        print("Item already in wishlist.")
                        continue
                    i += 1
            else:
                print("\nBut you can't enter any gifts! Program will not work, restarting fillout...\n")
                continue

        except ValueError:
            print("\nInvalid entry entered, try again.")
            continue

        print("\n")
        bday_wishlist = WishList(bday_name.title(), wishlist_amount, wishlist, address)
        print("\n" + bday_wishlist.__str__())


        while True:
            print("\n-=-=-=REVIEW WISHLIST=-=-=-")
            print("Either edit the wishlist in some way (add or delete a gift), decide whether to purchase the gifts, show what the wishlist looks like, or exit this part and continue\
to the next.")
            option = input("\nSelect what you would like to do:\n\
    ADD (A): Add a gift to the wishlist.\n\
    DELETE (D): Delete a gift from the wishlist.\n\
    PURCHASE (P): Purchase all the gifts in the wishlist.\n\
    SHOW WISHLIST (W): Print what the wishlist looks like.\n\
    QUIT (Q): Quit this part and go enter another person's birthday wishlist.\n")
            if option.upper() == "ADD" or option.upper() == "A":
                bday_wishlist.add_gift()
            elif option.upper() == "DELETE" or option.upper() == "D":
                bday_wishlist.delete_gift()
            elif option.upper() == "PURCHASE" or option.upper() == "P":
                bday_wishlist.purchase_gift()
                break
            elif option.upper() == "SHOW WISHLIST" or option.upper() == "WISHLIST" or option.upper() == "SHOW" or option.upper() == "W":
                print("\n" + bday_wishlist.__str__())
            elif option.upper() == "QUIT" or option.upper() == "Q":
                print("Ending program, going back to fillout sheet...\n")
                break
            else:
                print("Invalid option.")

        print("\n")
        print("=-=-=-WISHLIST GIFT TABLE-=-=-=")
        customer_name = input("What's the customer's name?: ")
        table_print([customer_name, bday_num], bday_wishlist.set_wl_list())
        bday_num += 1
    """
    
