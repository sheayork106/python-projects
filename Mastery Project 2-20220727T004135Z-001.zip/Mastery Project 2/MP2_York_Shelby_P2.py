def table_print(columns, data, column1, column2):
    #Goes ahead and asks a user for the title of their table
    title = input("\nGive me a title for your table: ")

    #Subtracts the values by 1 so they line up properly with the indices
    column1 -= 1
    column2 -= 1

    print("\n")

    #how it will be formatted. May change title later if I think it doesn't look right
    title_format = '{title:^50}'
    col_format = '{column1:<30} | {column2:>23}'

    #Bad practice of using the same variable name as the parameters for the formatting, but
    #       I could not think of a good name to represent it
    print("\n" + title_format.format(title = title))
    print(col_format.format(column1 = columns[column1], column2 = columns[column2]))
    print('-' * 44)

    #Also not the greatest, but it works
    for row in data:
        for position, item in enumerate(row):
            for position2, item2 in enumerate(row):
                if position == column1 and position2 == column2:
                    print(col_format.format(column1 = item, column2 = item2))

def selection_sort(data, sort_by = None):
    #If the user just hits enter, sort_by will automatically sort it by the last position
    if sort_by == None:
        sort_by = -1
    #Else, it subtracts it by 1 to find the right indice
    else:
        sort_by -= 1

    for i in range(len(data)-1):
        smallest = i
        for j in range(i+1, len(data)):
            if data[j][sort_by] < data[smallest][sort_by]:
                smallest = j

        #made a temporary version of data[i] because I kept running into errors trying to do two at once
        temp = data[i]
        data[i] = data[smallest]
        data[smallest] = temp

    return data


def tallied_data(data, column1, column2):
    #Subtracts it by 1 to find the right indice
    column1 -= 1
    column2 -= 1

    tallied_dict = {}

    for row in data:
        for position, item in enumerate(row):
            for position2, item2 in enumerate(row):
                #If it isn't already in there and they're in the right positions, it will be added to the dictionary
                if (position == column1 and position2 == column2) and item not in tallied_dict:
                    tallied_dict[item] = item2
                #If it is in the dictionary and they're in the right positions, it will add to the existing key's value
                elif (position == column1 and position2 == column2) and item in tallied_dict:
                    tallied_dict[item] += item2
        
    #Turns every key, value to a nested list, then calls for selection sort to put them in order. Because this is in descending, have to reverse the results
    tallied_list = list(tallied_dict.items())
    sorted_tallied_list = selection_sort(tallied_list)
    sorted_tallied_list.reverse()
    print(sorted_tallied_list)
