import MP2_York_Shelby_Part2 as part_two
def option_a(year, data, columns):
    given_year_data = []
    for row in data:
        for item in row:
            try:
                item = eval(item)
            except:
                item

            if type(item) is int and item == year:
                given_year_data.append(row)


    candidates_totalvotes = []
    for row in given_year_data:
        if not row[3]:
            continue
        candidates_totalvotes.append((row[3], int(row[6])))

    overall_votes_dict = {}
    for name, votes in candidates_totalvotes:
        if name not in overall_votes_dict:
            overall_votes_dict[name] = votes
        elif name in overall_votes_dict:
            overall_votes_dict[name] += votes

    overall_votes = []
    for key in overall_votes_dict:
        overall_votes.append((key, overall_votes_dict[key]))
        
    overall_votes = part_two.sort_lists(overall_votes)
    overall_votes.reverse()

    part_two.table_print(columns, overall_votes, year)

def option_b(year, data, columns):
    given_year_data = []
    for row in data:
        for item in row:
            try:
                item = eval(item)
            except:
                item

            if type(item) is int and item == year:
                given_year_data.append(row)


    parties_totalvotes = []
    for row in given_year_data:
        if not row[4]:
            continue
        parties_totalvotes.append((row[4], int(row[6])))

    overall_votes_dict = {}
    for party, votes in parties_totalvotes:
        if party not in overall_votes_dict:
            overall_votes_dict[name] = votes
        elif party in overall_votes_dict:
            overall_votes_dict[name] += votes

    overall_votes = []
    for key in overall_votes_dict:
        overall_votes.append((key, overall_votes_dict[key]))
        
    overall_votes = part_two.sort_lists(overall_votes)
    overall_votes.reverse()

    part_two.table_print(columns, overall_votes, year)

def option_c(year):
    print("C")

def option_d(year):
    print("D")
