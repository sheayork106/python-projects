import MP2_York_Shelby_P2 as part_two
#A: Total candidate votes
def option_a(data):
    
    candidate_votes = []
    #If the candidate name is blank, I didn't count it. I uh...don't exactly know what write-ins are
    for row in data:
        if row[4] != "":
            party_votes.append((row[4], int(row[7])))
    
    for row in data:
        candidate_votes.append((row[3], int(row[7])))
    #Checks if the candidate is already in. If they aren't, they are added and given the value in the list. If they are, it just adds the value on the list and leaves the name alone
    overall_votes_dict = {}
    for name, votes in candidate_votes:
        if name not in overall_votes_dict:
            overall_votes_dict[name] = votes
        elif name in overall_votes_dict:
            overall_votes_dict[name] += votes

    #In the end, I turn each key and value into a nested list again, and I reverse the order. To make it easier on myself, I made the new column headers and assigned col1, col2 so my
            #table_print function still worked
    overall_votes = list((key, overall_votes_dict[key]) for key in overall_votes_dict)
    candidate_total_votes = reversed(part_two.selection_sort(overall_votes))
    columns_a = ["CANDIDATE", "TOTALVOTES"]
    col1, col2 = 1, 2
    part_two.table_print(columns_a, candidate_total_votes, col1, col2)

#B: Total party votes
def option_b(data):
    party_votes = []
    #If the party name is blank, I didn't count it. I uh...don't exactly know what write-ins are
    for row in data:
        if row[4] != "":
            party_votes.append((row[4], int(row[7])))
    #Same thing as A, but with checking if the party names are in the list or not
    overall_votes_dict = {}
    for name, votes in party_votes:
        if name not in overall_votes_dict:
            overall_votes_dict[name] = votes
        elif name in overall_votes_dict:
            overall_votes_dict[name] += votes

    #Same as A
    overall_votes = list((key, overall_votes_dict[key]) for key in overall_votes_dict)
    party_total_votes = reversed(part_two.selection_sort(overall_votes))
    columns_b = ["PARTY", "TOTALVOTES"]
    col1, col2 = 1, 2
    part_two.table_print(columns_b, party_total_votes, col1, col2)

#C: Total Write-ins
def option_c(data):
    #I simply went through each row to see if it was in the 5th indice and the item was true. So long as it's true, I added the total votes to it. 
    writein_total = 0
    for row in data:
        for position, item in enumerate(row):
            if position == 5 and item == "TRUE":
                writein_total += int(row[7])

    return writein_total

#D: Who got popular vote
def option_d(data):
    #Decided to use the selection sort to make the code shorter. So long as the first one has the most, it should still give the correct output
    popular_vote = part_two.selection_sort(data, 8)
    #This returns the 3rd and 7th indice values. When it goes to print, I have to use indices again in order to format the print statement properly. 
    return (popular_vote[0][3], popular_vote[0][7])
