import csv

def election_data(file_name):
    print("\tOpening file " + file_name + "...")
    
    with open(file_name, 'r') as f:
        file_contents = csv.reader(f, delimiter = ',')
        file_contents_cleanup = []

        for row in file_contents:
            file_contents_cleanup.append(row)
            
    return(file_contents_cleanup) 
                



if __name__ in "__main__":
    print("--COLLECT ELECTION DATA--")
    print("Enter the file with the data (include anything after the period!), and also enter what election year you want to look at.")

    election_file = input("\nEnter election years file: ")

    
    #FIXME: Needs to keep asking until it can locate the file
    election_results = election_data(election_file)


    election_columns = election_results[0]
    del election_results[0]

    print("\tData collected! There are " + str(len(election_results)) + " rows.")
    election_year = int(input("\nEnter the election year you want to see: "))


    print("\n")
    for row in election_results:
        if int(row[0]) == election_year:
            print(row)
    print("\n")


    print("*" * 30)
    import MP2_York_Shelby_Part2 as part_two
    
    print("\n~~DATA TABLE~~\nThis will present all of the data in your file. Enter what two columns you would like to look at!\n")
    part_two.table_print(election_columns, election_results)

    print("\n~~SORT THE DATA~~\nGive a list of lists with data in it, then say what column you want it sorted by.\n")
    nested_data = eval(input("Enter your lists here: "))
    sortby = int(input("What do you want to sort it by?: "))
    sortby -= 1
    print(part_two.sort_lists(nested_data, sortby))

    print("\n~~TALLY THE DATA~~\nGiven the lists before, give me a number to say which item you would like the total of.\n")
    part_two.tallied_data(nested_data)
    print("\n")



    print("*" * 30)
    import MP2_York_Shelby_Part3 as part_three
    
    print("\n~~REFINING DATA~~\nChoose a question you would like to have answered!\n")
    vote_year = int(input("Give me a year: "))

    print("\n")
    
    print("\tA. Given " + str(vote_year) + ", how many votes did each candidate get throughout the country?")
    print("\tB. Given " + str(vote_year) + ", how many votes did each party get throughout the country?")
    print("\tC. Given " + str(vote_year) + ", how many votes were 'write-in' votes?")
    print("\tD. Given " + str(vote_year) + ", who won popular vote?")
    question = input("Choose a letter: ")

    if question.upper() == "A":
        part_three.option_a(vote_year, election_results, election_columns)
    elif question.upper() == "B":
        part_three.option_a(vote_year, election_results, election_columns)
    elif question.upper() == "C":
        part_three.option_c(vote_year)
    elif question.upper() == "D":
        part_three.option_d(vote_year)
    else:
        print("Invalid letter.")


    print("\nThank you for using this program!")
