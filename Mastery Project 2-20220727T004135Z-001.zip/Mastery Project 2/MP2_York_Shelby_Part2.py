def table_print(columns, data, year = 0):
    title = input("\nInsert a title for the table here: ")

    col1 = int(input("Enter digit for column 1: "))
    col2 = int(input("Enter digit for column 2: "))

    col1 -= 1
    col2 -= 1


    title_format = '{title:^50}'
    col_format = '{column1:<30} | {column2:>23}'

    print("\n" + title_format.format(title = title))
    print(col_format.format(column1 = columns[col1], column2 = columns[col2]))
    print('-' * 44)

    #Not the most efficient way, but it works
    for row in data:
        for position, item in enumerate(row):
            for position2, item2 in enumerate(row):
                if position == col1 and position2 == col2:
                    print(col_format.format(column1 = item, column2 = item2))

def sort_lists(data, sort_by=None):

    if sort_by == None:
        sort_by = -1
    
    for i in range(len(data)-1):
        smallest = i
        for j in range(i+1, len(data)):
            if data[j][sort_by] < data[smallest][sort_by]:
                smallest = j

        temp = data[i]
        data[i] = data[smallest]
        data[smallest] = temp

    return data

def tallied_data(data):
    col1 = int(input("Give me the position of the first element you want (Either 1 or 3): "))
    col2 = int(input("Give me the position of the second element you want (Either 2 or 4): "))

    col1 -= 1
    col2 -= 1

    tallied_dict = {}
    col2_total = 0
    
    for row in data:
        for position, item in enumerate(row):
            for position2, item2 in enumerate(row):
                if (position == col1 and position2 == col2) and item not in tallied_dict:
                    tallied_dict[item] = item2
                elif (position == col1 and position2 == col2) and item in tallied_dict:
                    tallied_dict[item] += item2


    tallied_list = list(tallied_dict.items())
    sorted_tallied_list = sort_lists(tallied_list)
    sorted_tallied_list.reverse()
    print(sorted_tallied_list)

