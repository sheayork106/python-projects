"""
MASTERY PROJECT 02 - Election Data
---
For this code, I decided to stick with the inital election year the user gave, as I wasn't for sure if the instructions meant a new year or was referencing to the one
the user previously gave. Throughout the code, there are comments like this establishing the order of the program I took and what it's dealing with. Again, it's 1 and part of 3, the
second part of 3, and 2 because I didn't know what the instructions meant. If it's through one year, I decided it would be best to go in this order instead.

Also, for the second part of 3, I decided to make one more module so I can go through it easier than through here. I was able 

If I forgot to submit any files along with this, please let me know. Otherwise, I hope I made clear enough comments! 

"""


import csv
"""
STEP 1: Collect the data. Ask the user for the file and collect the data from it. Close the file, then tell the user you got it. Tell them how many rows there are (should be 3740
based on the file given).
Afterwards, ask the user for a year of data they want to look at, and print them all.
    -Does it tell the user if the file doesn't work?: Yes, lines 15 to 26
    -Does it accurately tell them how many rows there are?: Yes, line 49
    -Does it use DictReader?: No. I couldn't figure it out.
    -Did you use list comprehension to read the years?: Yes, line 63. Not for sure if the 'squeeze text' button will count, though.
    -Did you give the user a message when you collected the data?: Yes, line 49
"""
def collect_data(file_name):
    #This is where the code will be read. Instead of using DictReader, I made a list to append the lists
    #Using with was a lot easier because just .readlines() added '\n' at the end. With this, it doesn't. Life saver, I'm telling you.
    try:
        with open(file_name, 'r') as file:
            file_contents = csv.reader(file, delimiter = ',')
            file_cleanup = []

            for row in file_contents:
                file_cleanup.append(row)
        return file_cleanup

    #If the file was inputted wrong or it just isn't in the directory, the program ends.
    #Tried to add '.csv' to the end if the user said yes to a question, but kept running into string errors. Is there a way to do this?
    except:
        print("\nFile does not exist. Please try again when you have the file. Program ending.")


#Where all the inputs and calls should be
if __name__ in "__main__":

    """
    STEP 3a: Refine the data.
        -Asks the user for the file and election year - Yes
        -Checks to see if the user gives the wrong file or year - Yes for the first one, no for the second. My else statement doesn't work for some reason. Otherwise, it does
            check if the user wants to see the election data as a table or not. If it is ever invalid, it should stop.
        -
    """
    #Part 1 instructions and such
    print("~~COLLECT ELECTION DATA FROM FILE~~\n\
Enter the name of the file with the data. Be sure to include the file type.\n\
If no file type is provided, your entry may automatically have '.csv' added to it.")
    #Where to input the file name (MUST INCLUDE .CSV TO WORK)
    election_file = input("\tEnter your election data file: ")

    #So long as it has '.csv,' it will work. If '.csv' is elsewhere, still won't continue because it's an invalid file
    if ".csv" in election_file:
        print("\tAccessing " + election_file + "...")
        election_results = collect_data(election_file)
        
        #So long as election_results isn't empty, it will go through the program
        if election_results:
            #This part takes the columns so I can use them for later.
            election_columns = election_results[0]
            del election_results[0]
            #The amount of rows there are
            print("\tData collected! There are " + str(len(election_results)) + " rows!")

            #Asks the user for a year, then checks to see if year is equal to it
            print("\n---Election Year Data?---\n\t\
If there's a specific year you want to see, put it below! If not, put -1.")
            election_year = int(input("Give an election year or enter -1: "))
            if election_year != -1:
                election_year_data = []
                for row in election_results:
                    #If it is, append it to the list
                    if int(row[0]) == election_year:
                        election_year_data.append(row)

                #List comprehension to show the rows. If the length is 0, that means the year is not an election year
                print([row if len(election_year_data) != 0 else "Invalid year" for row in election_year_data])
                print("\n")

            elif election_year == -1:
                print("Skipping Election Year Data...\n")

            else:
                print("Not a valid integer. Continuing program.")


            """
            STEP 3b: Multiple Modules. Focus on specific data and print out a table for each one.
                -Asks the user which question they'd like to answer - Yes
                -Looks at total votes for candidates in the whole country (table) - Yes
                -Looks at total votes for parties in the whole country (table) - Yes
                -Looks at how many were 'write-in' votes (statement) - Yes
                -Looks to see who won the popular vote (statement) -  Yes
                -Gives the user a message saying the program is done -  Yes
            """

            print("*" * 30)
            #THIS IS MYMOD_3
            import MP2_York_Shelby_P3 as part_three
            print("\n~~NARROWING DATA DOWN!~~\n\t\
Based on the data and election year given, the program will print out a table or a statement to answerone of the following:")
            print("\tA. How many total votes did a candidate get?\n\
\tB. How many total votes did each party get?\n\
\tC. How many votes were 'write-in' votes?\n\
\tD. Who won the popular vote?\n")
            question = input("Which question would you liked answered?: ")
            if question.upper() == "A":
                part_three.option_a(election_year_data)
            elif question.upper() == "B":
                part_three.option_b(election_year_data)
            elif question.upper() == "C":
                print("\tIn " + str(election_year) + ", there were " + str(part_three.option_c(election_year_data)) + " write-ins.")
            elif question.upper() == "D":
                print("\tIn " + str(election_year) + ", " + str(part_three.option_d(election_year_data)[0]) + " got the popular vote with " + str(part_three.option_d(election_year_data)[1]) + " votes!")
            else:
                print("Not a valid letter. Continuing program.\n")

            print("\n")
            

            """
            STEP 2: Multiple Modules. Make your own modules to do the following: prints a table of the data (I think for the given election year), sorts the lists
                    by a given column (sort_by), and tallies up the votes for a column, depending on what the user chooses.
                            -Do you have a table_print?: Yes, it's called on line 94
                            -Do you use some kind of sorting method?: Yes, it's called on line 105 and uses selection sort 
                            -Do you have a tallied_data? Does it correctly collect the data?: Yes, it's called on line 111
            """
            #So long as everything above worked out, we still go with step 2. FIXME: If the file doesn't work, would the user still want to do this step?
            #I know the formatting for the print statements are weird, but if I indent them, it also affects how it prints out. I don't know why it does this.
            print("*" * 30)
            #THIS IS MYMOD_2
            import MP2_York_Shelby_P2 as part_two
            print("\n~~PRINT A TABLE!~~\n\t\
This will present all the data in the data, so long as they're in the given year.\
Give me two column numbers and I'll sort through them.")
            print("\tThese are the following columns:\n\
\t1 = Year\n\
\t2 = State\n\
\t3 = State's Abbriviation\n\
\t4 = Candidate's Name\n\
\t5 = Candidate's Party\n\
\t6 = Write-Ins\n\
\t7 = Candidate's Votes for the State\n\
\t8 = Candidate's Total Votes throughout the Nation.")
            col1 = int(input("Give me a name for column 1: "))
            col2 = int(input("Also for column 2: "))
            part_two.table_print(election_columns, election_year_data, col1, col2)

            print("\n")
            print("*" * 30)
            print("\n~~USING NEW LISTS!~~\n\
\tSo long as you give me some lists, the program will go through three different procedures!")
            nested_lists = eval(input("Put your lists here!: "))

            print("\n---Sort Your Data---\n\t\
\tThis will sort your data in descending order depending on how you want the data to be sorted. It will not affect the order of the lists!\n\
\tIf you don't care how it's ordered, just hit enter and it will be sorted based on the last position.")
            sort = int(input("Which column would you like it sorted by?: "))
            print(part_two.selection_sort(nested_lists, sort))

            print("\n---Tally Your Data---\n\t\
Depending on the columns you choose, this will add up votes and sort them in descending order.")
            col1 = int(input("\nWhat items do you want counted for column 1?: "))
            col2 = int(input("What numbers are being tallied for column 2?: "))
            part_two.tallied_data(nested_lists, col1, col2)

            print("\n")
            print("*" * 30)
            print("\nThis is the end of the program! Thank you for using it!")


        #If not true, there is no data in it, and the program ends
        else:
            print("There is no data in the file. Program ending.")

    #If file type not provided, the program ends.
    else:
        print("\nYou did not say what file type it is. Please try again later. Program ending")
