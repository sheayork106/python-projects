import urllib.request, os, re

#SECTION 1 - Parse the website, save the information, and print it.
def retrieve_web_info():
    web_info = urllib.request.urlopen("https://news.luddy.indiana.edu/")
    content = web_info.read().decode(errors = 'replace')
    web_info.close()
    return content

#SECTION 2 - Look through all of the lines of the HTML code. If it's an article, it should be saved to a list. Once it's all done, each article should be printed off.
        # Noticed that each article has 'story.html' in the link. I may need to look through each line and see every instance of it.
        # Since each word of the actual story is seperated with a dash, I need to use [\w-]+ to look for every single instance of that happening in the links
def find_articles(web_content):
    return re.findall(r'https://news.luddy.indiana.edu/story.html\W\w+\W[\w-]+', web_content, re.DOTALL)

def find_headlines(web_content):
    #headlines = re.findall('(?<=div class="head5">)[\w ]+', web_content)
    #headlines = re.findall(r'(?<=div class="head5">)[\.]+', web_content)
    #Need to fix this because it won't take dollar signs and such
    headlines = re.findall('(?<=div class="head5">).+?(?=</div>)', web_content)
    return headlines

def find_dates(web_content):
    dates = re.findall(r'[\s]*(?<=div class="small meta">)\w+ \d{2}, \d{4}', web_content)
    return dates

if __name__ == '__main__':
    print("MASTER PROJECT 1\n\
For this program, I'll be taking the Luddy Hall News website (https://news.luddy.indiana.edu/) and showing all the main story headlines. Then you, the user, can give me a date.\n\
This date is related to when articles were published. If there were any on that date, I'll print them off. If not, I'll let you know.")
    print("=" * 25)
    
    print(retrieve_web_info())
    article_links = find_articles(retrieve_web_info())
    article_headlines = find_headlines(retrieve_web_info())
    article_dates = find_dates(retrieve_web_info())

    print("\nPART 1: All Article Headlines")
    for article in article_headlines:
        print("\t" + article)
        
    print("\n")
    print("~" * 15)
    
    print("\nPART 2: Find Articles According to Date")
    print("This is usually how the dates are laid out for Luddy Hall's news website: Jan, Feb, Mar, Apr, May, Jun, Jul. There aren't any news articles past July. Give me a month and day, and I'll try to find articles correlated to that date!")
    user_date = input("Input a date (i.e.: Jun 21): ")
    user_date = user_date + ", 2021"
    print(article_dates)
